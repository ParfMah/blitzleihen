<?php
/**
 * Secrets réels du site — NE JAMAIS pousser ce fichier sur GitHub
 * (déjà exclu par .gitignore). Il ne reste que les identifiants MySQL
 * à compléter ci-dessous, une fois la base créée dans cPanel (voir
 * GUIDE-DEPLOIEMENT-PHP.md, étape 2).
 */

// --- Base de données MySQL — [⚠ À COMPLÉTER après l'étape 2 du guide] ---
define('DB_HOST', 'localhost');
define('DB_NAME', '');      // ex. blitz444_leihen
define('DB_USER', '');      // ex. blitz444_leihenuser
define('DB_PASS', '');      // le mot de passe choisi à la création

// --- Sécurité ---
define('APP_SECRET', '8c510eb83fdfbc4c6e1f74d959b2a409129e8c5015f250663cf292e98f0344c8128db13946a1dfdbb9f4cd5e8702fdaa');

// Origines autorisées pour les appels depuis le frontend (CORS)
define('FRONTEND_ORIGINS', 'https://www.blitzleihen.com,https://blitzleihen.com');

// --- Email sortant (SMTP) ---
define('SMTP_HOST', 'mail.blitzleihen.com');
define('SMTP_PORT', 465);
define('SMTP_SECURE', true);
define('SMTP_USER', 'noreply@blitzleihen.com');
define('SMTP_PASS', 'Paf2015!!');
define('EMAIL_FROM_NAME', 'Blitz Leihen');
define('EMAIL_FROM_ADDRESS', 'noreply@blitzleihen.com');
define('KREDIT_EMAIL', 'kredit@blitzleihen.com');
define('HILFE_EMAIL', 'hilfe@blitzleihen.com');
define('KONTAKT_EMAIL', 'kontakt@blitzleihen.com');

// --- Compte admin créé par scripts/seed.php ---
define('ADMIN_EMAIL', 'info@blitzleihen.com');
define('ADMIN_PASSWORD', 'BlitzAdmin2025!');
define('ADMIN_NAME', 'Günther Th. Hoheisel');

// --- Durée de validité d'une session admin, en heures ---
define('TOKEN_LIFETIME_HOURS', 8);
